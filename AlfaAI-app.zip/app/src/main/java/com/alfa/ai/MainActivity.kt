package com.alfa.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.alfa.ai.ui.ChatScreen
import com.alfa.ai.ui.ChatViewModel
import com.alfa.ai.ui.StudioScreen
import com.alfa.ai.ui.StudioViewModel
import com.alfa.ai.ui.theme.Amber
import com.alfa.ai.ui.theme.Ink
import com.alfa.ai.ui.theme.Muted
import com.alfa.ai.ui.theme.Panel
import com.alfa.ai.ui.theme.Paper
import com.alfa.ai.ui.theme.AlfaTheme

private enum class Tab { CHAT, GENERATE }

class MainActivity : ComponentActivity() {

    private val chatViewModel: ChatViewModel by viewModels()
    private val studioViewModel: StudioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AlfaTheme {
                AlfaApp(chatViewModel, studioViewModel)
            }
        }
    }
}

@Composable
private fun AlfaApp(chatViewModel: ChatViewModel, studioViewModel: StudioViewModel) {
    var tab by remember { mutableStateOf(Tab.CHAT) }

    Scaffold(
        containerColor = Ink,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(
                    selected = tab == Tab.CHAT,
                    onClick = { tab = Tab.CHAT },
                    icon = { Icon(Icons.Filled.Chat, contentDescription = null) },
                    label = { Text("Chat") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Ink,
                        selectedTextColor = Amber,
                        indicatorColor = Amber,
                        unselectedIconColor = Muted,
                        unselectedTextColor = Muted
                    )
                )
                NavigationBarItem(
                    selected = tab == Tab.GENERATE,
                    onClick = { tab = Tab.GENERATE },
                    icon = { Icon(Icons.Filled.Movie, contentDescription = null) },
                    label = { Text("Generate") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Ink,
                        selectedTextColor = Amber,
                        indicatorColor = Amber,
                        unselectedIconColor = Muted,
                        unselectedTextColor = Muted
                    )
                )
            }
        }
    ) { padding ->
        androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                Tab.CHAT -> ChatScreen(chatViewModel)
                Tab.GENERATE -> StudioScreen(studioViewModel)
            }
        }
    }
}
