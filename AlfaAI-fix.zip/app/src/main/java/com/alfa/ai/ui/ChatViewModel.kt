package com.alfa.ai.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alfa.ai.data.AnthropicRepository
import com.alfa.ai.data.ChatResult
import com.alfa.ai.data.ChatTurn
import com.alfa.ai.data.ImageUtils
import com.alfa.ai.data.KeyStore
import com.alfa.ai.voice.TtsController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String, // "user" or "assistant"
    val text: String,
    val imagePreviewUri: Uri? = null,
    val imageMediaType: String? = null,
    val imageBase64: String? = null,
    val fromVideo: Boolean = false
)

data class PendingAttachment(
    val previewUri: Uri,
    val mediaType: String,
    val base64: String,
    val fromVideo: Boolean
)

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val pendingAttachment: PendingAttachment? = null,
    val attachmentProcessing: Boolean = false,
    val sending: Boolean = false,
    val error: String? = null,
    val hasAnthropicKey: Boolean = false,
    val speakReplies: Boolean = true,
    val listening: Boolean = false
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val keyStore = KeyStore(application)
    private val repository = AnthropicRepository(keyStore)
    private val tts = TtsController(application)

    private val _uiState = MutableStateFlow(
        ChatUiState(hasAnthropicKey = !keyStore.getAnthropicKey().isNullOrBlank())
    )
    val uiState: StateFlow<ChatUiState> = _uiState

    fun setInput(value: String) = _uiState.update { it.copy(input = value) }

    fun setSpeakReplies(enabled: Boolean) {
        tts.enabled = enabled
        _uiState.update { it.copy(speakReplies = enabled) }
        if (!enabled) tts.stop()
    }

    fun setListening(value: Boolean) = _uiState.update { it.copy(listening = value) }

    fun saveAnthropicKey(key: String) {
        keyStore.setAnthropicKey(key)
        _uiState.update { it.copy(hasAnthropicKey = key.isNotBlank(), error = null) }
    }

    fun attachImage(uri: Uri) {
        _uiState.update { it.copy(attachmentProcessing = true) }
        viewModelScope.launch {
            val encoded = withContext(Dispatchers.IO) {
                ImageUtils.uriToEncodedImage(getApplication(), uri)
            }
            if (encoded == null) {
                _uiState.update { it.copy(attachmentProcessing = false, error = "Couldn't read that image.") }
            } else {
                _uiState.update {
                    it.copy(
                        attachmentProcessing = false,
                        pendingAttachment = PendingAttachment(uri, encoded.mediaType, encoded.base64, fromVideo = false)
                    )
                }
            }
        }
    }

    fun attachVideoFrame(uri: Uri) {
        _uiState.update { it.copy(attachmentProcessing = true) }
        viewModelScope.launch {
            val encoded = withContext(Dispatchers.IO) {
                ImageUtils.videoUriToFrame(getApplication(), uri)
            }
            if (encoded == null) {
                _uiState.update { it.copy(attachmentProcessing = false, error = "Couldn't read that video.") }
            } else {
                _uiState.update {
                    it.copy(
                        attachmentProcessing = false,
                        pendingAttachment = PendingAttachment(uri, encoded.mediaType, encoded.base64, fromVideo = true)
                    )
                }
            }
        }
    }

    fun clearAttachment() = _uiState.update { it.copy(pendingAttachment = null) }

    fun send() {
        val state = _uiState.value
        if (state.input.isBlank() && state.pendingAttachment == null) return
        if (!state.hasAnthropicKey) {
            _uiState.update { it.copy(error = "Add your Anthropic API key in Settings first.") }
            return
        }

        val attachment = state.pendingAttachment
        val userMessage = ChatMessage(
            role = "user",
            text = state.input,
            imagePreviewUri = attachment?.previewUri,
            imageMediaType = attachment?.mediaType,
            imageBase64 = attachment?.base64,
            fromVideo = attachment?.fromVideo ?: false
        )

        val newMessages = state.messages + userMessage
        _uiState.update {
            it.copy(messages = newMessages, input = "", pendingAttachment = null, sending = true, error = null)
        }

        viewModelScope.launch {
            val history = newMessages.map {
                ChatTurn(role = it.role, text = it.text, imageMediaType = it.imageMediaType, imageBase64 = it.imageBase64)
            }
            when (val result = repository.send(history)) {
                is ChatResult.Success -> {
                    val reply = ChatMessage(role = "assistant", text = result.reply)
                    _uiState.update { it.copy(messages = it.messages + reply, sending = false) }
                    if (_uiState.value.speakReplies) tts.speak(result.reply)
                }
                is ChatResult.Failure -> {
                    _uiState.update { it.copy(sending = false, error = result.message) }
                }
            }
        }
    }

    fun speak(text: String) = tts.speak(text)
    fun stopSpeaking() = tts.stop()

    override fun onCleared() {
        tts.shutdown()
        super.onCleared()
    }
}
