package com.alfa.ai.data

data class AnthropicRequest(
    val model: String,
    val max_tokens: Int = 1024,
    val messages: List<AnthropicMessage>
)

data class AnthropicMessage(
    val role: String, // "user" or "assistant"
    val content: List<AnthropicContentBlock>
)

// Only one of the fields below is populated per block, matching Anthropic's
// tagged content-block shape (type = "text" or "image").
data class AnthropicContentBlock(
    val type: String,
    val text: String? = null,
    val source: AnthropicImageSource? = null
)

data class AnthropicImageSource(
    val type: String = "base64",
    val media_type: String,
    val data: String
)

data class AnthropicResponse(
    val content: List<AnthropicResponseBlock>? = null,
    val error: AnthropicError? = null
)

data class AnthropicResponseBlock(
    val type: String,
    val text: String? = null
)

data class AnthropicError(
    val message: String? = null
)

fun textMessage(role: String, text: String): AnthropicMessage =
    AnthropicMessage(role, listOf(AnthropicContentBlock(type = "text", text = text)))

fun imageAndTextMessage(role: String, text: String, mediaType: String, base64: String): AnthropicMessage =
    AnthropicMessage(
        role,
        listOf(
            AnthropicContentBlock(
                type = "image",
                source = AnthropicImageSource(media_type = mediaType, data = base64)
            ),
            AnthropicContentBlock(type = "text", text = text.ifBlank { "Describe what you see." })
        )
    )
