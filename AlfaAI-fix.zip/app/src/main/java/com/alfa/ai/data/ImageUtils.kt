package com.alfa.ai.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream

data class EncodedImage(val mediaType: String, val base64: String)

/**
 * Reads a picked image or video, downsamples/extracts a frame, and encodes
 * it as JPEG. Two output shapes are provided: a data URI (for Replicate's
 * image-input models) and a raw base64 + media type pair (for Anthropic's
 * vision API, which wants those as separate fields).
 */
object ImageUtils {

    fun uriToBase64DataUri(
        context: Context,
        uri: Uri,
        maxDimension: Int = 1024,
        quality: Int = 85
    ): String? {
        val bitmap = decodeSampledBitmap(context, uri, maxDimension) ?: return null
        val base64 = bitmapToBase64(bitmap, quality) ?: return null
        return "data:image/jpeg;base64,$base64"
    }

    fun uriToEncodedImage(
        context: Context,
        uri: Uri,
        maxDimension: Int = 1024,
        quality: Int = 85
    ): EncodedImage? {
        val bitmap = decodeSampledBitmap(context, uri, maxDimension) ?: return null
        val base64 = bitmapToBase64(bitmap, quality) ?: return null
        return EncodedImage(mediaType = "image/jpeg", base64 = base64)
    }

    /** Grabs a frame partway through a video for the model to look at, since no
     *  vision API can watch full video — this is a real limitation, not a corner cut. */
    fun videoUriToFrame(
        context: Context,
        uri: Uri,
        maxDimension: Int = 1024,
        quality: Int = 85
    ): EncodedImage? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val frameTimeUs = (durationMs / 2) * 1000
            val frame = retriever.getFrameAtTime(frameTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(0)
                ?: return null

            val scaled = scaleBitmap(frame, maxDimension)
            val base64 = bitmapToBase64(scaled, quality) ?: return null
            EncodedImage(mediaType = "image/jpeg", base64 = base64)
        } catch (e: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap, quality: Int): String? {
        return try {
            val output = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)
            Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    private fun scaleBitmap(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val ratio = maxDimension.toFloat() / maxOf(bitmap.width, bitmap.height)
        if (ratio >= 1f) return bitmap
        val width = (bitmap.width * ratio).toInt()
        val height = (bitmap.height * ratio).toInt()
        return Bitmap.createScaledBitmap(bitmap, width, height, true)
    }

    private fun decodeSampledBitmap(context: Context, uri: Uri, maxDimension: Int): Bitmap? {
        val resolver = context.contentResolver

        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOptions)
        }

        var sampleSize = 1
        val width = boundsOptions.outWidth
        val height = boundsOptions.outHeight
        while (width / sampleSize > maxDimension || height / sampleSize > maxDimension) {
            sampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        return resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOptions)
        }
    }
}
