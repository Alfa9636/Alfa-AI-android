package com.alfa.ai.data

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/** Result of a generation call, used by the ViewModel. */
sealed class PredictionResult {
    data class Success(val id: String, val status: String, val outputUrl: String?) : PredictionResult()
    data class Failure(val message: String) : PredictionResult()
}

class ReplicateRepository(private val keyStore: KeyStore) {

    // Default models — override by passing different owner/name strings.
    // Any Replicate model that accepts a "prompt" input works here.
    var imageModel: String = "black-forest-labs/flux-schnell"
    var videoModel: String = "minimax/video-01"

    // Used instead of imageModel when a reference photo is attached (image editing / img2img).
    var imageEditModel: String = "black-forest-labs/flux-kontext-pro"

    private val authInterceptor = Interceptor { chain ->
        val token = keyStore.getReplicateKey().orEmpty()
        val request = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer $token")
            .addHeader("Content-Type", "application/json")
            .build()
        chain.proceed(request)
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .build()

    private val api: ReplicateApi = Retrofit.Builder()
        .baseUrl("https://api.replicate.com/v1/")
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(ReplicateApi::class.java)

    suspend fun generate(
        mode: GenerationMode,
        prompt: String,
        aspectRatio: String?,
        negativePrompt: String?,
        imageDataUri: String? = null
    ): PredictionResult {
        if (keyStore.getReplicateKey().isNullOrBlank()) {
            return PredictionResult.Failure("Add your Replicate API key in Settings first.")
        }

        val hasImage = !imageDataUri.isNullOrBlank()
        val modelString = when {
            mode == GenerationMode.PHOTO && hasImage -> imageEditModel
            mode == GenerationMode.PHOTO -> imageModel
            else -> videoModel // video model handles both text-to-video and image-to-video
        }
        val (owner, model) = modelString.split("/", limit = 2).let { it[0] to it[1] }

        val input = buildMap<String, Any?> {
            put("prompt", prompt)
            aspectRatio?.let { put("aspect_ratio", it) }
            negativePrompt?.takeIf { it.isNotBlank() }?.let { put("negative_prompt", it) }
            if (hasImage) {
                if (mode == GenerationMode.PHOTO) {
                    put("input_image", imageDataUri)
                } else {
                    put("first_frame_image", imageDataUri)
                }
            }
        }

        return try {
            val response = api.createPrediction(owner, model, CreatePredictionRequest(input))
            val body = response.body()
            if (!response.isSuccessful || body == null) {
                PredictionResult.Failure(parseError(response.errorBody()?.string()))
            } else {
                PredictionResult.Success(body.id, body.status, body.output.firstOutputUrl())
            }
        } catch (e: Exception) {
            PredictionResult.Failure(e.message ?: "Network error")
        }
    }

    suspend fun checkStatus(id: String): PredictionResult {
        return try {
            val response = api.getPrediction(id)
            val body = response.body()
            if (!response.isSuccessful || body == null) {
                PredictionResult.Failure(parseError(response.errorBody()?.string()))
            } else if (body.status == "failed" || body.status == "canceled") {
                PredictionResult.Failure(body.error ?: "Generation failed.")
            } else {
                PredictionResult.Success(body.id, body.status, body.output.firstOutputUrl())
            }
        } catch (e: Exception) {
            PredictionResult.Failure(e.message ?: "Network error")
        }
    }

    private fun parseError(raw: String?): String {
        if (raw.isNullOrBlank()) return "Something went wrong."
        return try {
            com.google.gson.JsonParser.parseString(raw)
                .asJsonObject.get("detail")?.asString ?: raw
        } catch (e: Exception) {
            raw
        }
    }
}
