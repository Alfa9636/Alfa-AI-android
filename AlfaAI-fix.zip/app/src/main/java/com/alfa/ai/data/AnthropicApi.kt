package com.alfa.ai.data

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface AnthropicApi {
    @Headers("anthropic-version: 2023-06-01")
    @POST("v1/messages")
    suspend fun sendMessage(@Body body: AnthropicRequest): Response<AnthropicResponse>
}
