package com.alfa.ai.data

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

sealed class ChatResult {
    data class Success(val reply: String) : ChatResult()
    data class Failure(val message: String) : ChatResult()
}

/** One turn in the visible chat history, used both as UI state and as the payload we resend each call. */
data class ChatTurn(
    val role: String, // "user" or "assistant"
    val text: String,
    val imageMediaType: String? = null,
    val imageBase64: String? = null
)

class AnthropicRepository(private val keyStore: KeyStore) {

    var model: String = "claude-sonnet-4-5"

    private val authInterceptor = Interceptor { chain ->
        val key = keyStore.getAnthropicKey().orEmpty()
        val request = chain.request().newBuilder()
            .addHeader("x-api-key", key)
            .addHeader("Content-Type", "application/json")
            .build()
        chain.proceed(request)
    }

    private val client = OkHttpClient.Builder().addInterceptor(authInterceptor).build()

    private val api: AnthropicApi = Retrofit.Builder()
        .baseUrl("https://api.anthropic.com/")
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(AnthropicApi::class.java)

    suspend fun send(history: List<ChatTurn>): ChatResult {
        if (keyStore.getAnthropicKey().isNullOrBlank()) {
            return ChatResult.Failure("Add your Anthropic API key in Settings first.")
        }

        val messages = history.map { turn ->
            if (turn.role == "user" && turn.imageBase64 != null && turn.imageMediaType != null) {
                imageAndTextMessage(turn.role, turn.text, turn.imageMediaType, turn.imageBase64)
            } else {
                textMessage(turn.role, turn.text)
            }
        }

        return try {
            val response = api.sendMessage(AnthropicRequest(model = model, messages = messages))
            val body = response.body()
            if (!response.isSuccessful || body == null) {
                ChatResult.Failure(body?.error?.message ?: "Anthropic error (${response.code()})")
            } else if (body.error != null) {
                ChatResult.Failure(body.error.message ?: "Something went wrong.")
            } else {
                val text = body.content.orEmpty()
                    .filter { it.type == "text" && it.text != null }
                    .joinToString("\n") { it.text!! }
                ChatResult.Success(text)
            }
        } catch (e: Exception) {
            ChatResult.Failure(e.message ?: "Network error")
        }
    }
}
