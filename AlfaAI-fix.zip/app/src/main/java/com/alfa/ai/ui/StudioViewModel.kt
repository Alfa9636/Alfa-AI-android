package com.alfa.ai.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alfa.ai.data.GenerationMode
import com.alfa.ai.data.ImageUtils
import com.alfa.ai.data.KeyStore
import com.alfa.ai.data.PredictionResult
import com.alfa.ai.data.ReplicateRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class JobStatus { STARTING, PROCESSING, SUCCEEDED, FAILED }

data class GenerationJob(
    val localId: String = UUID.randomUUID().toString(),
    val remoteId: String? = null,
    val mode: GenerationMode,
    val prompt: String,
    val status: JobStatus,
    val outputUrl: String? = null,
    val error: String? = null
)

data class StudioUiState(
    val mode: GenerationMode = GenerationMode.PHOTO,
    val prompt: String = "",
    val negativePrompt: String = "",
    val aspectRatio: String = "1:1",
    val submitting: Boolean = false,
    val formError: String? = null,
    val jobs: List<GenerationJob> = emptyList(),
    val hasReplicateKey: Boolean = false,
    val attachedImageUri: Uri? = null,
    val attachedImageBase64: String? = null,
    val imageProcessing: Boolean = false
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val keyStore = KeyStore(application)
    private val repository = ReplicateRepository(keyStore)

    private val _uiState = MutableStateFlow(
        StudioUiState(hasReplicateKey = !keyStore.getReplicateKey().isNullOrBlank())
    )
    val uiState: StateFlow<StudioUiState> = _uiState

    fun setMode(mode: GenerationMode) = _uiState.update { it.copy(mode = mode) }
    fun setPrompt(value: String) = _uiState.update { it.copy(prompt = value) }
    fun setNegativePrompt(value: String) = _uiState.update { it.copy(negativePrompt = value) }
    fun setAspectRatio(value: String) = _uiState.update { it.copy(aspectRatio = value) }

    fun saveReplicateKey(key: String) {
        keyStore.setReplicateKey(key.trim())
        _uiState.update { it.copy(hasReplicateKey = key.isNotBlank(), formError = null) }
    }

    fun attachImage(uri: Uri) {
        _uiState.update { it.copy(attachedImageUri = uri, imageProcessing = true, attachedImageBase64 = null) }
        viewModelScope.launch {
            val dataUri = withContext(Dispatchers.IO) {
                ImageUtils.uriToBase64DataUri(getApplication(), uri)
            }
            if (dataUri == null) {
                _uiState.update {
                    it.copy(
                        imageProcessing = false,
                        attachedImageUri = null,
                        formError = "Couldn't read that image — try a different one."
                    )
                }
            } else {
                _uiState.update { it.copy(imageProcessing = false, attachedImageBase64 = dataUri) }
            }
        }
    }

    fun clearAttachedImage() {
        _uiState.update { it.copy(attachedImageUri = null, attachedImageBase64 = null) }
    }

    fun generate() {
        val state = _uiState.value
        if (state.prompt.isBlank()) {
            _uiState.update { it.copy(formError = "Write a prompt before generating.") }
            return
        }
        if (!state.hasReplicateKey) {
            _uiState.update { it.copy(formError = "Add your Replicate API key in Settings first.") }
            return
        }

        _uiState.update { it.copy(submitting = true, formError = null) }

        viewModelScope.launch {
            val result = repository.generate(
                mode = state.mode,
                prompt = state.prompt,
                aspectRatio = state.aspectRatio,
                negativePrompt = state.negativePrompt,
                imageDataUri = state.attachedImageBase64
            )

            when (result) {
                is PredictionResult.Success -> {
                    val job = GenerationJob(
                        remoteId = result.id,
                        mode = state.mode,
                        prompt = state.prompt,
                        status = statusFrom(result.status),
                        outputUrl = result.outputUrl
                    )
                    _uiState.update { it.copy(submitting = false, jobs = listOf(job) + it.jobs) }
                    if (job.status != JobStatus.SUCCEEDED) pollJob(job.localId, result.id)
                }
                is PredictionResult.Failure -> {
                    _uiState.update { it.copy(submitting = false, formError = result.message) }
                }
            }
        }
    }

    private fun pollJob(localId: String, remoteId: String) {
        viewModelScope.launch {
            while (true) {
                delay(2500)
                val result = repository.checkStatus(remoteId)
                when (result) {
                    is PredictionResult.Success -> {
                        val status = statusFrom(result.status)
                        updateJob(localId) { it.copy(status = status, outputUrl = result.outputUrl) }
                        if (status == JobStatus.SUCCEEDED) break
                    }
                    is PredictionResult.Failure -> {
                        updateJob(localId) { it.copy(status = JobStatus.FAILED, error = result.message) }
                        break
                    }
                }
            }
        }
    }

    private fun updateJob(localId: String, transform: (GenerationJob) -> GenerationJob) {
        _uiState.update { state ->
            state.copy(jobs = state.jobs.map { if (it.localId == localId) transform(it) else it })
        }
    }

    private fun statusFrom(remote: String): JobStatus = when (remote) {
        "starting" -> JobStatus.STARTING
        "processing" -> JobStatus.PROCESSING
        "succeeded" -> JobStatus.SUCCEEDED
        else -> JobStatus.FAILED
    }
}
