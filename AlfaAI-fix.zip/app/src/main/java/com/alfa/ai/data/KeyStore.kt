package com.alfa.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores API keys on-device using AES256-GCM via the Jetpack Security
 * library. Keys never leave the device except in the Authorization/x-api-key
 * header of requests the user's own accounts make.
 */
class KeyStore(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "alfa_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun getReplicateKey(): String? = prefs.getString(KEY_REPLICATE, null)
    fun setReplicateKey(value: String) = prefs.edit().putString(KEY_REPLICATE, value.trim()).apply()

    fun getAnthropicKey(): String? = prefs.getString(KEY_ANTHROPIC, null)
    fun setAnthropicKey(value: String) = prefs.edit().putString(KEY_ANTHROPIC, value.trim()).apply()

    companion object {
        private const val KEY_REPLICATE = "replicate_api_token"
        private const val KEY_ANTHROPIC = "anthropic_api_key"
    }
}
