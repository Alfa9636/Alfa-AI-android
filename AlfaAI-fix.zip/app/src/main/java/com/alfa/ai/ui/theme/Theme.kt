package com.alfa.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

val Ink = Color(0xFF12141C)
val Panel = Color(0xFF181B25)
val BorderGray = Color(0xFF2A2E3A)
val Paper = Color(0xFFEDEAE3)
val Muted = Color(0xFF8B8F9E)
val Amber = Color(0xFFE8A33D)
val Cyan = Color(0xFF7DD3E8)
val Danger = Color(0xFFE8636F)

private val AlfaColors = darkColorScheme(
    background = Ink,
    surface = Panel,
    primary = Amber,
    onPrimary = Ink,
    secondary = Cyan,
    error = Danger,
    onBackground = Paper,
    onSurface = Paper
)

@Composable
fun AlfaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AlfaColors,
        typography = MaterialTheme.typography.copy(
            // System serif/mono stand in for Fraunces/Plex Mono without bundling font files.
            titleLarge = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif),
            labelSmall = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace)
        ),
        content = content
    )
}
