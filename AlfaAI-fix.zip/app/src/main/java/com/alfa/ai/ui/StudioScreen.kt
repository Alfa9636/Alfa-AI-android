package com.alfa.ai.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.alfa.ai.data.GenerationMode
import com.alfa.ai.ui.theme.Amber
import com.alfa.ai.ui.theme.BorderGray
import com.alfa.ai.ui.theme.Danger
import com.alfa.ai.ui.theme.Ink
import com.alfa.ai.ui.theme.Muted
import com.alfa.ai.ui.theme.Panel
import com.alfa.ai.ui.theme.Paper

private val ASPECTS = listOf("1:1", "16:9", "9:16", "4:3")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(viewModel: StudioViewModel) {
    val state by viewModel.uiState.collectAsState()
    var showKeyDialog by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let { viewModel.attachImage(it) } }

    if (showKeyDialog) {
        ApiKeyDialog(
            currentKeyPresent = state.hasReplicateKey,
            onDismiss = { showKeyDialog = false },
            onSave = {
                viewModel.saveReplicateKey(it)
                showKeyDialog = false
            }
        )
    }

    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Generate", color = Paper, style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { showKeyDialog = true }) {
                Icon(Icons.Filled.Settings, contentDescription = "Replicate API key settings", tint = Paper)
            }
        }
        Column(
            Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            if (!state.hasReplicateKey) {
                Surface(
                    color = Panel,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Text(
                        "Add your Replicate API key (tap the gear, top right) to start generating.",
                        color = Muted,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            ModeToggle(state.mode, viewModel::setMode)

            OutlinedTextField(
                value = state.prompt,
                onValueChange = viewModel::setPrompt,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                label = { Text("Prompt") },
                placeholder = {
                    Text(
                        if (state.mode == GenerationMode.PHOTO)
                            "A weathered lighthouse at dusk, storm breaking"
                        else "Slow dolly-in on a lighthouse as storm clouds break"
                    )
                },
                minLines = 3
            )

            OutlinedTextField(
                value = state.negativePrompt,
                onValueChange = viewModel::setNegativePrompt,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                label = { Text("Exclude (optional)") },
                placeholder = { Text("blurry, watermark, text") },
                singleLine = true
            )

            Text(
                if (state.mode == GenerationMode.PHOTO) "Reference photo (optional)" else "Animate a photo (optional)",
                color = Muted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
            )
            AttachedImageRow(
                imageUri = state.attachedImageUri,
                processing = state.imageProcessing,
                onPick = {
                    imagePicker.launch(
                        androidx.activity.result.PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.ImageOnly
                        )
                    )
                },
                onClear = viewModel::clearAttachedImage
            )

            Text(
                "Aspect ratio",
                color = Muted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ASPECTS.forEach { ratio ->
                    AspectChip(
                        label = ratio,
                        selected = state.aspectRatio == ratio,
                        onClick = { viewModel.setAspectRatio(ratio) }
                    )
                }
            }

            state.formError?.let {
                Text(
                    it,
                    color = Danger,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            Button(
                onClick = viewModel::generate,
                enabled = !state.submitting,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = Amber,
                    contentColor = Ink
                )
            ) {
                if (state.submitting) {
                    CircularProgressIndicator(modifier = Modifier.height(18.dp), color = Ink)
                } else {
                    Text(if (state.mode == GenerationMode.PHOTO) "Generate still" else "Generate clip")
                }
            }

            Text(
                if (state.attachedImageBase64 != null)
                    (if (state.mode == GenerationMode.PHOTO) "Model: flux-kontext-pro (image editing)" else "Model: video-01 (image-to-video)")
                else
                    (if (state.mode == GenerationMode.PHOTO) "Model: flux-schnell (text-to-image)" else "Model: video-01 (text-to-video)"),
                color = Muted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 12.dp)
            )

            Text(
                "Light table",
                color = Muted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(state.jobs) { job -> JobCard(job) }
            }
        }
    }
}

@Composable
private fun ModeToggle(mode: GenerationMode, onChange: (GenerationMode) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGray, RoundedCornerShape(4.dp))
            .padding(4.dp)
    ) {
        listOf(GenerationMode.PHOTO to "Still", GenerationMode.VIDEO to "Motion").forEach { (m, label) ->
            val selected = mode == m
            Surface(
                color = if (selected) Amber else Panel,
                shape = RoundedCornerShape(4.dp),
                onClick = { onChange(m) },
                modifier = Modifier
                    .weight(1f)
                    .padding(2.dp)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        color = if (selected) Ink else Muted,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun AttachedImageRow(
    imageUri: android.net.Uri?,
    processing: Boolean,
    onPick: () -> Unit,
    onClear: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (imageUri != null) {
            Box(
                Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .border(1.dp, BorderGray, RoundedCornerShape(4.dp))
            ) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = "Attached photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (processing) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Ink.copy(alpha = 0.6f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Amber)
                    }
                }
            }
            IconButton(onClick = onClear) {
                Icon(Icons.Filled.Close, contentDescription = "Remove photo", tint = Muted)
            }
        } else {
            OutlinedButton(onClick = onPick) {
                Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(" Attach photo", modifier = Modifier.padding(start = 4.dp))
            }
        }
    }
}

@Composable
private fun AspectChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) Amber.copy(alpha = 0.15f) else Panel,
        shape = RoundedCornerShape(4.dp),
        onClick = onClick,
        modifier = Modifier.border(1.dp, if (selected) Amber else BorderGray, RoundedCornerShape(4.dp))
    ) {
        Text(
            label,
            color = if (selected) Amber else Muted,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun JobCard(job: GenerationJob) {
    Column(
        Modifier
            .border(1.dp, BorderGray, RoundedCornerShape(4.dp))
            .background(Panel, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(Ink),
            contentAlignment = Alignment.Center
        ) {
            when (job.status) {
                JobStatus.STARTING, JobStatus.PROCESSING -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Amber, modifier = Modifier.height(24.dp))
                        Text(
                            if (job.status == JobStatus.STARTING) "Loading emulsion…" else "Developing…",
                            color = Amber,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
                JobStatus.FAILED -> {
                    Text(
                        job.error ?: "Generation failed.",
                        color = Danger,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                JobStatus.SUCCEEDED -> {
                    val url = job.outputUrl
                    if (url != null) {
                        if (job.mode == GenerationMode.PHOTO) {
                            AsyncImage(
                                model = url,
                                contentDescription = job.prompt,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            VideoPlayer(url, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }
        }
        Text(
            job.prompt,
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}
