package com.alfa.ai.data

import com.google.gson.JsonElement

data class CreatePredictionRequest(
    val input: Map<String, Any?>
)

data class PredictionDto(
    val id: String,
    val status: String,
    val output: JsonElement? = null,
    val error: String? = null
)

enum class GenerationMode { PHOTO, VIDEO }

/**
 * Pulls the first URL out of a Replicate "output" field, which can be
 * either a single string or a list of strings depending on the model.
 */
fun JsonElement?.firstOutputUrl(): String? {
    if (this == null || isJsonNull) return null
    return when {
        isJsonPrimitive -> asString
        isJsonArray && asJsonArray.size() > 0 -> asJsonArray[0].asString
        else -> null
    }
}
