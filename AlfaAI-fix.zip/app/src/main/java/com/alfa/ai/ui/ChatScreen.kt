package com.alfa.ai.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.alfa.ai.ui.theme.Amber
import com.alfa.ai.ui.theme.BorderGray
import com.alfa.ai.ui.theme.Danger
import com.alfa.ai.ui.theme.Ink
import com.alfa.ai.ui.theme.Muted
import com.alfa.ai.ui.theme.Panel
import com.alfa.ai.ui.theme.Paper
import java.util.Locale

@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showKeyDialog by remember { mutableStateOf(false) }

    if (showKeyDialog) {
        ApiKeyDialog(
            title = "Anthropic API key",
            serviceName = "Anthropic",
            placeholder = "sk-ant-...",
            currentKeyPresent = state.hasAnthropicKey,
            onDismiss = { showKeyDialog = false },
            onSave = {
                viewModel.saveAnthropicKey(it)
                showKeyDialog = false
            }
        )
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let { viewModel.attachImage(it) } }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let { viewModel.attachVideoFrame(it) } }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        viewModel.setListening(false)
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) {
                viewModel.setInput((state.input + " " + text).trim())
            }
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.setListening(true)
            speechLauncher.launch(buildSpeechIntent())
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Chat", color = Paper, style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.VolumeUp, contentDescription = null, tint = Muted, modifier = Modifier.size(18.dp))
                Switch(
                    checked = state.speakReplies,
                    onCheckedChange = viewModel::setSpeakReplies,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                IconButton(onClick = { showKeyDialog = true }) {
                    Icon(Icons.Filled.Settings, contentDescription = "Anthropic API key settings", tint = Paper)
                }
            }
        }

        if (!state.hasAnthropicKey) {
            Surface(color = Panel, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Text(
                    "Add your Anthropic API key (tap the gear, top right) to start chatting.",
                    color = Muted,
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(state.messages) { message ->
                MessageBubble(message = message, onSpeak = { viewModel.speak(it) })
            }
            if (state.sending) {
                item {
                    Surface(color = Panel, shape = RoundedCornerShape(4.dp)) {
                        Text(
                            "Thinking…",
                            color = Amber,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }

        state.error?.let {
            Text(it, color = Danger, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        }

        state.pendingAttachment?.let { attachment ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(4.dp)).border(1.dp, BorderGray, RoundedCornerShape(4.dp))) {
                    AsyncImage(model = attachment.previewUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                Text(
                    if (attachment.fromVideo) " Frame from video attached" else " Photo attached",
                    color = Muted,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(start = 8.dp)
                )
                IconButton(onClick = viewModel::clearAttachment) {
                    Text("×", color = Muted)
                }
            }
        }

        if (state.attachmentProcessing) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Amber)
        }

        Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = {
                imagePicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) {
                Icon(Icons.Filled.AttachFile, contentDescription = "Attach photo", tint = Muted)
            }
            IconButton(onClick = {
                videoPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
            }) {
                Text("▶", color = Muted, modifier = Modifier.padding(4.dp))
            }
            IconButton(onClick = {
                val granted = androidx.core.content.ContextCompat.checkSelfPermission(
                    context, Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) {
                    viewModel.setListening(true)
                    speechLauncher.launch(buildSpeechIntent())
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }) {
                Icon(
                    Icons.Filled.Mic,
                    contentDescription = "Speak",
                    tint = if (state.listening) Amber else Muted
                )
            }

            OutlinedTextField(
                value = state.input,
                onValueChange = viewModel::setInput,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Say something…") },
                maxLines = 4
            )

            IconButton(onClick = viewModel::send, enabled = !state.sending) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = Amber)
            }
        }
    }
}

private fun buildSpeechIntent() =
    android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now…")
    }

@Composable
private fun MessageBubble(message: ChatMessage, onSpeak: (String) -> Unit) {
    val isUser = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (isUser) Amber.copy(alpha = 0.12f) else Panel,
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .border(1.dp, if (isUser) Amber.copy(alpha = 0.4f) else BorderGray, RoundedCornerShape(4.dp))
        ) {
            Column(Modifier.padding(12.dp)) {
                message.imagePreviewUri?.let {
                    AsyncImage(
                        model = it,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(160.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .padding(bottom = 8.dp)
                    )
                }
                if (message.text.isNotBlank()) {
                    Text(message.text, color = Paper, style = MaterialTheme.typography.bodyMedium)
                }
                if (!isUser && message.text.isNotBlank()) {
                    IconButton(onClick = { onSpeak(message.text) }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Filled.VolumeUp, contentDescription = "Read aloud", tint = Muted, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
