package com.alfa.ai.data

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

interface ReplicateApi {

    @POST("models/{owner}/{model}/predictions")
    suspend fun createPrediction(
        @Path("owner") owner: String,
        @Path("model") model: String,
        @Body body: CreatePredictionRequest,
        @Header("Prefer") prefer: String = "wait=1"
    ): Response<PredictionDto>

    @GET("predictions/{id}")
    suspend fun getPrediction(@Path("id") id: String): Response<PredictionDto>
}
