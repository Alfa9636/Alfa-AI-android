package com.alfa.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Wraps Android's built-in TextToSpeech engine. On init, scans available
 * voices for the deepest-sounding male-leaning option the device offers,
 * and additionally lowers pitch a notch for a heavier, "deep" tone —
 * there's no universal "snoring" voice in TTS engines, so this is the
 * closest honest equivalent: a low-pitched, low-register male voice.
 */
class TtsController(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false
    var enabled: Boolean = true

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                applyDeepVoice()
            }
        }
    }

    private fun applyDeepVoice() {
        val engine = tts ?: return
        engine.language = Locale.US

        val voices: Set<Voice> = try {
            engine.voices ?: emptySet()
        } catch (e: Exception) {
            emptySet()
        }

        val deepVoice = voices
            .filter { !it.isNetworkConnectionRequired && it.locale.language == "en" }
            .firstOrNull { voice ->
                val name = voice.name.lowercase()
                name.contains("male") || name.contains("#male") || name.contains("-d-") || name.contains("m3")
            }

        if (deepVoice != null) {
            engine.voice = deepVoice
        }

        // Lower pitch and slightly slow the rate for a heavier, deeper delivery
        // regardless of which voice got selected above.
        engine.setPitch(0.75f)
        engine.setSpeechRate(0.95f)
    }

    fun speak(text: String) {
        if (!enabled || text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alfa_utterance")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
