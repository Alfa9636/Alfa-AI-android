# Alfa AI — Chat, Generate, Analyze, Talk

A native Kotlin + Jetpack Compose Android app: chat with Claude (with voice
input and a deep-voiced spoken reply), generate photos and video, and hand it
a photo or video to analyze — all using your own API keys.

## Features

- **Chat** — talk to Claude via Anthropic's API. Tap the mic to speak instead
  of typing; toggle "speak replies" to have it read answers back in a
  deep, low-pitched voice (Android's TTS engine, tuned down in pitch/rate —
  the closest honest equivalent to "deep voice," since no TTS engine ships an
  actual snoring voice).
- **Attach & analyze** — attach a photo for the model to look at and describe
  or answer questions about. Attach a video and the app extracts one frame
  (no vision API can watch full video yet) and analyzes that.
- **Generate** — Still/Motion toggle, prompt, optional reference photo.
  With a photo attached, Still mode edits it and Motion mode animates it.

Two API keys, entered in-app (gear icon on each tab) and stored **encrypted
on-device** via Android's Jetpack Security library:
- Anthropic key → Chat tab (get one at console.anthropic.com/settings/keys)
- Replicate key → Generate tab (get one at replicate.com/account/api-tokens)

## Build it — takes about 10 minutes, no computer required (see below)

### With a computer
1. Install Android Studio (free)
2. **File → Open** → select this unzipped `AlfaAI` folder
3. Let it sync (accept the Gradle wrapper prompt if shown)
4. **Build → Build APK(s)**, or plug in your phone and hit **Run**

### Phone only, via GitHub Actions
1. Create a GitHub repo (e.g. `alfa-ai-android`)
2. **Add file → Create new file** → name it `.github/workflows/build-apk.yml`
   → paste in the contents of `.github/workflows/build-apk.yml` from this
   project → commit
3. **Add file → Upload files** → upload `AlfaAI.zip` (zip this whole folder
   first, or use the one already provided alongside this project) → commit.
   This triggers the build automatically.
4. **Actions** tab → wait for the green check (~5 min)
5. Open the run → **Artifacts** → download `alfa-ai-debug-apk`
6. Extract it, tap `app-debug.apk`, allow installs from that source, **Install**

## Changing models

`AnthropicRepository.kt`:
```kotlin
var model: String = "claude-sonnet-4-5"
```
`ReplicateRepository.kt`:
```kotlin
var imageModel: String = "black-forest-labs/flux-schnell"
var imageEditModel: String = "black-forest-labs/flux-kontext-pro"
var videoModel: String = "minimax/video-01"
```

## About "without limits, does everything"

No artificial cap exists anywhere in this code — no message counter, no
generation limit, no throttle. Real limits still apply: your own accounts'
rate limits and spend caps on both providers, and each provider's usage
policies, enforced on their end — true of any AI product. Video
*understanding* (vs. generation) is a genuine current gap across the
industry, not a corner cut here: this app analyzes one extracted frame from
a video rather than claiming to watch the whole thing, because that's the
honest state of what vision APIs can do today.
